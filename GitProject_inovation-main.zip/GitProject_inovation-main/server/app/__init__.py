from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from flask_bcrypt import Bcrypt
import os
from dotenv import load_dotenv
from app.utils.json_db import JsonDB

load_dotenv()

# Replace MongoDB with JSON DB
db_path = os.path.join(os.getcwd(), 'db.json')
json_db = JsonDB(db_path)

class MongoHelper:
    def __init__(self, db):
        self.db = db
    
    @property
    def users(self):
        return self.db.get_collection('users')

class MockMongo:
    def __init__(self, db):
        self.db = MongoHelper(db)

mongo = MockMongo(json_db)
bcrypt = Bcrypt()
jwt = JWTManager()

def create_app():
    app = Flask(__name__)
    
    # Config
    app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'default_secret_key')
    app.config['MAX_CONTENT_LENGTH'] = int(os.getenv('MAX_CONTENT_LENGTH', 16777216))
    
    # Initialize extensions
    CORS(app, origins=[os.getenv('CLIENT_URL', 'http://localhost:3000')])
    # mongo.init_app(app) # Not needed for JSON DB
    bcrypt.init_app(app)
    jwt.init_app(app)
    
    # Register blueprints
    from app.routes.auth import auth_bp
    from app.routes.profile import profile_bp
    
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(profile_bp, url_prefix='/api/users')
    
    # Error handlers
    @app.errorhandler(400)
    def bad_request(error):
        return {'error': 'Bad request'}, 400
    
    @app.errorhandler(401)
    def unauthorized(error):
        return {'error': 'Unauthorized'}, 401
    
    @app.errorhandler(404)
    def not_found(error):
        return {'error': 'Not found'}, 404
    
    @app.errorhandler(500)
    def internal_error(error):
        return {'error': 'Internal server error'}, 500
    
    return app
